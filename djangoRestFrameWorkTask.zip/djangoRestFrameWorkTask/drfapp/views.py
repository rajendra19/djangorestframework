from rest_framework.views import APIView
from rest_framework.response import Response
from drfapp.models import Dose
from drfapp.serializers import DoseSerializer


class LastDoseView(APIView):
    def get(self, request, machine_id):
        try:
            last_dose = Dose.objects.filter(patient__machine__machine_id=machine_id).latest('dose_id')
        except Dose.DoesNotExist:
            return Response({'error': 'No doses found for the given machine ID.'}, status=404)

        serializer = DoseSerializer(last_dose)
        return Response(serializer.data)
