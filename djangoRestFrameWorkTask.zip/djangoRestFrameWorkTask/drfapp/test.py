import requests

URL='http://localhost:8000/api/<machine_id>/'
r=requests.get(url=URL)
last_dose=r.json()
print(last_dose)